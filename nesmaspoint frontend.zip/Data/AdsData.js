export default [
  {
    name: "Toyota Yaris 2009 Red",
    price: "12,800",
    image:
      "https://images.unsplash.com/photo-1616455579100-2ceaa4eb2d37?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Ym13JTIwY2FyfGVufDB8fDB8fHww&w=1000&q=80",
  },
  {
    name: "Toyata Yaris 2023 White",
    price: "22,000",
    image:
      "https://toyota-indus.com/wp-content/uploads/2023/04/YARIS-AERO-ALL-NEW-SLEEK-AND-STYLISH-SIDE-SKIRTS.png",
  },
  {
    name: "Toyota Fortuner White",
    price: "32,000",
    image:
      "https://upload.wikimedia.org/wikipedia/commons/6/66/2015_Toyota_Fortuner_%28New_Zealand%29.jpg",
  },
  {
    name: "Hundai Tuscon 2021 Black",
    price: "27,500",
    image:
      "https://stimg.cardekho.com/images/carexteriorimages/930x620/Hyundai/Tucson/10136/1684743559495/front-left-side-47.jpg",
  },
  {
    name: "Honda HRBD 2022 Black",
    price: "34,500",
    image:
      "https://cdni.autocarindia.com/utils/imageresizer.ashx?n=https://cms.haymarketindia.net/model/uploads/modelimages/Hyundai-Tucson-220720221406.jpg",
  },

  {
    name: "Toyota Fortuner Black 2021",
    price: "30,000",
    image:
      "https://cdn.motor1.com/images/mgl/02EE3/s1/toyota-fortuner-gr-sport-indonesia.jpg",
  },
  {
    name: "Toyata Yaris Red 2023",
    price: "21,000",
    image:
      "https://www.v3cars.com/media/model-imgs/1625718909-Toyota-Yaris.jpg",
  },
  {
    name: "Toyata Yaris 2023 White",
    price: "22,000",
    image:
      "https://toyota-indus.com/wp-content/uploads/2023/04/YARIS-AERO-ALL-NEW-SLEEK-AND-STYLISH-SIDE-SKIRTS.png",
  },
  {
    name: "Toyota Fortuner White",
    price: "32,000",
    image:
      "https://upload.wikimedia.org/wikipedia/commons/6/66/2015_Toyota_Fortuner_%28New_Zealand%29.jpg",
  },
  {
    name: "Toyota Yaris 2009 Red",
    price: "12,800",
    image:
      "https://images.unsplash.com/photo-1616455579100-2ceaa4eb2d37?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Ym13JTIwY2FyfGVufDB8fDB8fHww&w=1000&q=80",
  },
  {
    name: "Toyata Yaris 2023 White",
    price: "22,000",
    image:
      "https://toyota-indus.com/wp-content/uploads/2023/04/YARIS-AERO-ALL-NEW-SLEEK-AND-STYLISH-SIDE-SKIRTS.png",
  },
  {
    name: "Toyota Fortuner White",
    price: "32,000",
    image:
      "https://upload.wikimedia.org/wikipedia/commons/6/66/2015_Toyota_Fortuner_%28New_Zealand%29.jpg",
  },
  {
    name: "Hundai Tuscon 2021 Black",
    price: "27,500",
    image:
      "https://stimg.cardekho.com/images/carexteriorimages/930x620/Hyundai/Tucson/10136/1684743559495/front-left-side-47.jpg",
  },
  {
    name: "Honda HRBD 2022 Black",
    price: "34,500",
    image:
      "https://cdni.autocarindia.com/utils/imageresizer.ashx?n=https://cms.haymarketindia.net/model/uploads/modelimages/Hyundai-Tucson-220720221406.jpg",
  },

  {
    name: "Toyota Fortuner Black 2021",
    price: "30,000",
    image:
      "https://cdn.motor1.com/images/mgl/02EE3/s1/toyota-fortuner-gr-sport-indonesia.jpg",
  },
  {
    name: "Toyota Yaris 2009 Red",
    price: "12,800",
    image:
      "https://images.unsplash.com/photo-1616455579100-2ceaa4eb2d37?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Ym13JTIwY2FyfGVufDB8fDB8fHww&w=1000&q=80",
  },
  {
    name: "Toyata Yaris 2023 White",
    price: "22,000",
    image:
      "https://toyota-indus.com/wp-content/uploads/2023/04/YARIS-AERO-ALL-NEW-SLEEK-AND-STYLISH-SIDE-SKIRTS.png",
  },
  {
    name: "Toyota Fortuner White",
    price: "32,000",
    image:
      "https://upload.wikimedia.org/wikipedia/commons/6/66/2015_Toyota_Fortuner_%28New_Zealand%29.jpg",
  },
  {
    name: "Hundai Tuscon 2021 Black",
    price: "27,500",
    image:
      "https://stimg.cardekho.com/images/carexteriorimages/930x620/Hyundai/Tucson/10136/1684743559495/front-left-side-47.jpg",
  },
  {
    name: "Honda HRBD 2022 Black",
    price: "34,500",
    image:
      "https://cdni.autocarindia.com/utils/imageresizer.ashx?n=https://cms.haymarketindia.net/model/uploads/modelimages/Hyundai-Tucson-220720221406.jpg",
  },

  {
    name: "Toyota Fortuner Black 2021",
    price: "30,000",
    image:
      "https://cdn.motor1.com/images/mgl/02EE3/s1/toyota-fortuner-gr-sport-indonesia.jpg",
  },
  {
    name: "Toyata Yaris Red 2023",
    price: "21,000",
    image:
      "https://www.v3cars.com/media/model-imgs/1625718909-Toyota-Yaris.jpg",
  },
  {
    name: "Toyata Yaris 2023 White",
    price: "22,000",
    image:
      "https://toyota-indus.com/wp-content/uploads/2023/04/YARIS-AERO-ALL-NEW-SLEEK-AND-STYLISH-SIDE-SKIRTS.png",
  },
  {
    name: "Toyota Fortuner White",
    price: "32,000",
    image:
      "https://upload.wikimedia.org/wikipedia/commons/6/66/2015_Toyota_Fortuner_%28New_Zealand%29.jpg",
  },
  {
    name: "Toyota Yaris 2009 Red",
    price: "12,800",
    image:
      "https://images.unsplash.com/photo-1616455579100-2ceaa4eb2d37?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Ym13JTIwY2FyfGVufDB8fDB8fHww&w=1000&q=80",
  },
  {
    name: "Toyata Yaris 2023 White",
    price: "22,000",
    image:
      "https://toyota-indus.com/wp-content/uploads/2023/04/YARIS-AERO-ALL-NEW-SLEEK-AND-STYLISH-SIDE-SKIRTS.png",
  },
  {
    name: "Toyota Fortuner White",
    price: "32,000",
    image:
      "https://upload.wikimedia.org/wikipedia/commons/6/66/2015_Toyota_Fortuner_%28New_Zealand%29.jpg",
  },
  {
    name: "Hundai Tuscon 2021 Black",
    price: "27,500",
    image:
      "https://stimg.cardekho.com/images/carexteriorimages/930x620/Hyundai/Tucson/10136/1684743559495/front-left-side-47.jpg",
  },
  {
    name: "Honda HRBD 2022 Black",
    price: "34,500",
    image:
      "https://cdni.autocarindia.com/utils/imageresizer.ashx?n=https://cms.haymarketindia.net/model/uploads/modelimages/Hyundai-Tucson-220720221406.jpg",
  },

  {
    name: "Toyota Fortuner Black 2021",
    price: "30,000",
    image:
      "https://cdn.motor1.com/images/mgl/02EE3/s1/toyota-fortuner-gr-sport-indonesia.jpg",
  },
];
